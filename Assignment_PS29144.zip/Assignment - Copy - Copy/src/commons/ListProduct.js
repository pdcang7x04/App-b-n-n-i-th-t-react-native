import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default ListProduct = 
[
    {
      id: 1,
      name: 'Giường xếp Ottoman',
      id_Category: 1,
      category: 'Sofa',
      price: '9.282.000',
      images: 'https://nhaxinh.com/wp-content/uploads/2024/01/Giuong-xep-Ottoman-vai-VACT10096-300x200.jpg',
    },
    {
      id: 2,
      name: 'Giường xếp Ottoman',
      id_Category: 1,
      category: 'Sofa',
      price: '9.282.000',
      images: 'https://nhaxinh.com/wp-content/uploads/2024/01/Giuong-xep-Ottoman-vai-VACT10096-300x200.jpg',
    },
    {
      id: 3,
      name: 'Giường xếp Ottoman',
      id_Category: 1,
      category: 'Sofa',
      price: '9.282.000',
      images: 'https://nhaxinh.com/wp-content/uploads/2024/01/Giuong-xep-Ottoman-vai-VACT10096-300x200.jpg',
    },
    {
      id: 4,
      name: 'Giường xếp Ottoman',
      id_Category: 1,
      category: 'Sofa',
      price: '9.282.000',
      images: 'https://nhaxinh.com/wp-content/uploads/2024/01/Giuong-xep-Ottoman-vai-VACT10096-300x200.jpg',
    },
  ]

